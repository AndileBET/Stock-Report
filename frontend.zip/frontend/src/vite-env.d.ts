/// <reference types="vite/client" />

